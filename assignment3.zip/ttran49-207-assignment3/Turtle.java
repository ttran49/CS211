import java.util.Random;
class Turtle extends Critter{
	private int drControl=0; //control the flow of direction
	private int runControl=0; //control the numbers of time it runs for 1 direct
	private Direction direct = Direction.NONE;
	@Override public char getChar(){
		return 'T';
	}
	/** @param take in info
	*	
	*	return direction of the object
	*			choose 1 direction and run 5x before choose another direction
	*/
	@Override public Direction getMove(CritterInfo info){
		// every 5th choose direction based on the other 
		if (runControl%5 == 0){
			switch (drControl % 4){
				/**	The Order of Directions: decide by the remander when / by 4
				*		1/ SOUTH
				*		2/ WEST
				*		3/ NORTH
				*		4/ EAST		
				----------------------------------------------
				*	case structure:
				*		1/update the "direct" with new direct
				*		2/update direct control and runcontrol
				*		3/stop!					*/
				
				case 0:	direct= Direction.SOUTH;	 
						drControl++;runControl++;
						break;
						
				case 1: direct= Direction.WEST;		 
						drControl++;runControl++;
						break;
						
				case 2: direct= Direction.NORTH; 	 
						drControl++;runControl++;
						break;
						
				case 3: direct= Direction.EAST; 	 
						drControl++;runControl++;
						break;
			}
			
		} else {
			//update the # of run to keep up.
			runControl++;
		}
		
		//return the updated direction
		return direct;	
	}
}