import java.util.Random;
class Mouse extends Critter{
	private int control=1;
	@Override public char getChar(){
		return 'M';
	}
	@Override public Direction getMove(CritterInfo info){
		
		if (control%2 ==1){
			control++;
			return Direction.WEST;
		} else {
			control++;
			return Direction.NORTH;
		}
	}
}