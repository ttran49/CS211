import java.util.Random;
class Wolf extends Critter{
	private Direction directionz = Direction.NONE;
	private int drControl=0;
	private int runControl=0;
	@Override public char getChar(){
		return 'W';
	}
	@Override public Direction getMove(CritterInfo info){
		//random number and choose direction based on the number
		drControl = new Random().nextInt();
		if (runControl%5 == 0){
			switch (drControl % 5){
				/**	The Order of Directions: decide by the remander when / by 5
				*		1/ SOUTH
				*		2/ WEST
				*		3/ NORTH
				*		4/ EAST		
				*		5/ RANDOM
				----------------------------------------------
				*	case structure:
				*		1/update the "direct" with new direct
				*		2/update direct control and runcontrol
				*		3/stop!					*/
				
				case 0:	directionz= Direction.SOUTH;	 
						runControl++;
						break;
						
				case 1: directionz= Direction.WEST;		 
						runControl++;
						break;
						
				case 2: directionz= Direction.NORTH; 	 
						runControl++;
						break;
						
				case 3: directionz= Direction.EAST; 	 
						runControl++;
						break;
				
				case 4: int random = new Random().nextInt(Direction.values().length);
						directionz = Direction.values()[random];
						runControl++;
						break;
				
				case 5: directionz = Direction.NONE;
						runControl++;
						break;
			}
			
		} else {
			//update the # of run to keep up.
			runControl++;
		}
		
		//return the updated direction
		return directionz;	
		
	}
}