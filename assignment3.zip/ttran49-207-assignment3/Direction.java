/**
 *  Provides references to possible directions 
 */

public enum Direction {
	NORTH, SOUTH, EAST, WEST, NONE;
}