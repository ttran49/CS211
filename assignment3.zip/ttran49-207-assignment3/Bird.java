import java.util.Random;
class Bird extends Critter{
	@Override public char getChar(){
		return 'B';
	}
	@Override public Direction getMove(CritterInfo info){
		int random = new Random().nextInt(Direction.values().length);
		if (Direction.values()[random] == Direction.NONE){
			int random1 = new Random().nextInt(Direction.values().length);
			return Direction.values()[random1];
		}
		return Direction.values()[random];
	}

}