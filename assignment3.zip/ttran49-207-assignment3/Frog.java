import java.util.Random;
class Frog extends Critter {
	private int control =0;
	private Direction direction= Direction.NONE;
	@Override public char getChar(){
		return 'F';
	}
	@Override public Direction getMove(CritterInfo info){
		if (control %3 == 0){
			control++;
			int random= new Random().nextInt(Direction.values().length-1);
			direction= Direction.values()[random];
		} else {
			control ++;
		}
		return direction;
	}
}