import java.util.Date;
import java.util.*;

/**
 *  Performs various operations for practice with arrays
 *  and Java 
 *  
 *  @author Your Name Here
 *  @version Your GNumber Here
 */
 class ExtraCredit {
	/**
	 *  Reverse an array.
	 *  
	 *  Why are you doing this? Arrays are really critical to
	 *  all programming. You need to see common scenarios like
	 *  this a lot before you will become fast at using them.
	 *  
	 *  @param input the array to reverse
	 *  @return the revered array
	 */
	public static int[] arrayReverse(int[] input) {
		//replace following return with your code
		int temp;
		int start=0;
		int end= input.length-1;
		//0 1 2 3 4
		//0 4
		//1 3  
		//2 stays
		while(end> start){
			temp=input[start];
			input[start]=input[end];
			input[end]=temp;
			start++;
			end--;
		}
		return input;
	}
	
	/**
	 *  Determine whether an array of characters is a palindrome.
	 *  
	 *  Why are you doing this? Arrays are really critical to
	 *  all programming. You need to see common scenarios like
	 *  this a lot before you will become fast at using them.
	 *  
	 *  @param input the array to check
	 *  @return whether or not the array is a palindrome
	 */
	public static boolean arrayPalindrome(char[] input) {
		//replace following return with your code
		boolean output=true;
		int start=0;
		int end= input.length-1;
		while(end>start){
			if (input[start]!=input[end]){
				output=false;
			}
			start++;
			end--;
		}
		return output;
	}
	
	/**
	 *  Replicate each element in an array some number of times.
	 *  For example, the array input of [1,2,2,3] and numTimes of
	 *  2 would result in the array [1,1,2,2,2,2,3,3].
	 *  
	 *  Why are you doing this? Arrays are really critical to
	 *  all programming. You need to see common scenarios like
	 *  this a lot before you will become fast at using them.
	 *  
	 *  @param input the array to expand
	 *  @return whether or not the array is a palindrome
	 */
	public static int[] replicateElements(int[] input, int numTimes) {
		//replace following return with your code
		int[] output= new int[input.length * numTimes];
		int index=0;
		
		for (int i =0; i<input.length;i++){
			for(int j=0; j< numTimes;j++){
				//System.out.println(index);
				output[index]=input[i];
				index++;
			}
		}
		//System.out.println(Arrays.toString(output));
		return output;
	}
	
	/**
	 *  Remove consecutive duplicates in an array. For example,
	 *  the array input of [1,2,2,2,3,3,2] should return the array
	 *  [1,2,3,2].
	 *  
	 *  Why are you doing this? Arrays are really critical to
	 *  all programming. You need to see common scenarios like
	 *  this a lot before you will become fast at using them.
	 *  
	 *  @param input the array to remove consecutive duplicates from
	 *  @return the reduced array
	 */
	public static int[] removeConsecDuplicates(int[] input) {
		//replace following return with your code
		int size=1;
		int index=1;
		//0 0 0 1 1 1 2 2 2 
		for(int i = 1; i < input.length; i++) {
			if(input[i] != input[i - 1]) {
				size++;

			} 
		}
		//System.out.println(size);
		
		int[] output = new int[size];
		int temp= input[0];
		
		for(int j=0;j<input.length;j++){
			if(temp!=input[j]){
				output[index]=input[j];
				temp=input[j];
				index++;
			}
		}
		return output;
	}
	
	/**
	 *  Drop every nth element from an array. For example,
	 *  the array input of [1,2,2,7,8,1,77] and n = 3 should
	 *  result in: [1,2,7,8,77].
	 *  
	 *  Why are you doing this? Arrays are really critical to
	 *  all programming. You need to see common scenarios like
	 *  this a lot before you will become fast at using them.
	 *  
	 *  @param input the array to drop elements from
	 *  @param n which elements to drop (every nth)
	 *  @return the reduced array
	 */
	public static int[] removeEveryNthElem(int[] input, int n) {
		//replace following return with your code
		//System.out.println(Arrays.toString(input));
		int temp= (int)input.length/n;
		int[] output=new int[input.length-temp];
		int index=0;
		//System.out.println(Arrays.toString(input));
		for (int i =0;i<input.length;i++){
			if((i+1)%n!=0){
				output[index]=input[i];
				index++;
			}
		}
		return output;
	}
	
	/**
	 *  Slice out a certain part of the array from a given
	 *  start index to a given end index (inclusive). For example,
	 *  if the input array is [1,2,3,4,5,6,7] and the start index
	 *  is 2 and end index is 3, the resulting array will containing
	 *  [3,4].
	 *  
	 *  Why are you doing this? Arrays are really critical to
	 *  all programming. You need to see common scenarios like
	 *  this a lot before you will become fast at using them.
	 *  
	 *  @param input the array to take a slice from
	 *  @param startIndex the index to start from (inclusive)
	 *  @param endIndex the index to end at (inclusive)
	 *  @return the slice of the array requested
	 */
	public static char[] slice(char[] input, int startIndex, int endIndex) {
		//replace following return with your code
		//System.out.println(Arrays.toString(input));
		char[] output=new char[(endIndex-startIndex)+1];
		int index=0;
		for (int i= startIndex; i <endIndex+1; i++){
			output[index]=input[i];
			index++;
		}
		//System.out.println(Arrays.toString(output));
		return output;
	}
	
	/**
	 *  Reverse byte ordering. One hex character represents one nibble (4 bits,
	 *  or half a byte), so two hex characters is used to represent a single
	 *  byte. If you want to reverse the bytes you need to reverse the string
	 *  in pairs of nibbles not in individual nibbles.
	 *  
	 *  For example, the hex: AE3F20F0 represents 4 bytes: AE, 3F, 20, and F0
	 *  To reverse those bytes we would need to return: F0, 20, 3F, and AE (F0203FAE)
	 *  
	 *  Why are you doing this? Look up big-endian to little-endian conversion.
	 *  Also, this is more practice with arrays...
	 *  
	 *  @param input a character array representing a string of bytes stored as hex
	 *  @return the revered byte ordering
	 */
	public static char[] reverseByteOrdering(char[] input) {
		//replace following return with your code
		
		String[] tempString= new String[input.length/2];
		String asd="";
		String temp="";
		int start=0;
		int end= tempString.length-1;
		int tempindex=0;
		int index=0;
		
		if(input.length==2){
			return input;
		}else {
			//create a string[] wit the bytes
			for (int i=0;i<input.length;i=i+2){
				asd= asd+ input[i] + input[i+1];
				tempString[tempindex]=asd;
				asd="";
				tempindex++;
			}
			//reverse the string[]
			while(end> start){
				temp=tempString[start];
				tempString[start]=tempString[end];
				tempString[end]=temp;
				start++;
				end--;
			}
			//go throguh string[], add each char to input
			for (int j=0;j<tempString.length;j++){
				String a=tempString[j];
				//System.out.println(a);
				char c;
				input[index]= (c= a.charAt(0));
				//System.out.println(a.charAt(0));
				input[index+1]=(c= a.charAt(1));
				//System.out.println(a.charAt(1));
				index=index+2;
			}
		}
		//System.out.println(Arrays.toString(input));
		return input;
	}

	/**
	 *  Return a size1 x size2 array of Date objects (elements should not be null).
	 *  
	 *  Why are you doing this? Multi-dimensional arrays of objects require
	 *  slightly different proceedures to initialize them than primitives.
	 *  
	 *  @param size1 first dimension of the array
	 *  @param size2 second dimension of the array
	 *  @return a size1 x size2 array of Date objects with no null elements
	 */
	public static Date[][] multiDimDateArray(int size1, int size2) {
		//replace following return with your code
		Date[][] output= new Date[size1][size2];
		for(int i=0; i<size1;i++){
			for(int j=0;j<size2;j++){
				output[i][j]=new Date();
			}
		}
		return output;
	}
	
	/**
	 *  Count the number of nulls in an array of objects.
	 *  
	 *  Why are you doing this? It is always important to check in
	 *  an array of objects for null elements, so you need to know
	 *  how to do this.
	 *  
	 *  @param inputArray the array to look for nulls in
	 *  @return the number of elements of the array which are null
	 */
	public static int nullsInArray(Object[] inputArray) {
		//replace following return with your code
		int counter=0;
		for (int i=0;i < inputArray.length;i++){
			if (inputArray[i]== null){
				counter++;
			}
		}
		return counter;
	}
	
	/**
	 *  Returns an array of objects containing some number of StringBuffer,
	 *  NullPointerException, ArrayIndexOutOfBoundsException, and Date objects
	 *  (in that order). For example, input of 2 would result in an array
	 *  containing 2 StringBuffers, 2 NullPointerExceptions,
	 *  2 ArrayIndexOutOfBoundsExceptions, and 2 Dates.
	 *  
	 *  Note that all of these objects can be constructed with a zero parameter
	 *  constructor.
	 *  
	 *  Why are you doing this? Object is the parent of all classes in
	 *  the Java hierarchy. No, really, every class. That includes things like
	 *  exceptions as well as dates and utility classes. That means an Object 
	 *  array is incredibly powerful and you should understand how to make one.
	 *  
	 *  @param numEach the number of each object to put into a the array
	 *  @return an array of size numEach*4 containing numEach StringBuffer, NullPointerException, ArrayIndexOutOfBoundsException, and Date objects
	 */
	public static Object[] multiObjectArray(int numEach) {
		//replace following return with your code
		Object[] output= new Object[4*numEach];
		int i=0;
		int order=0;
		while(i<output.length){
			for(int j=0; j<numEach;j++){
				//System.out.println("i "+i);
				if(order==0){output[i]= new StringBuffer();}
				if(order==1){output[i]= new NullPointerException();}
				if(order==2){output[i]= new ArrayIndexOutOfBoundsException();}
				if(order==3){output[i]= new Date();}
				i++;
				}
				order++;
			}
			//System.out.println(order);
		
		//System.out.println(Arrays.toString(output));
		return output;
	}
	
}