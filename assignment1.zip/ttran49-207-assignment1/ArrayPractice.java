/** Assignment 1, before going on to check the code, I did google a few things but all of them were simple
*things like syntax,and such. 
*
*
*
*/
class ArrayPractice{
	public static int countInRange(int[] array,int minnum, int maxnum){
	// finding the different between 2 elements by using the indexes.
		int minnumindex=0;
		int maxnumindex=0;	
		int diffbetween;
		for(int i = 0; i < array.length; i++){ //go through the array and check for the numbers' indexes
			if(array[i] == minnum){//chekcing for the index of the smaller numbers
				minnumindex= i;
			} 
			else if(array[i]== maxnum){//checking index of bigger numbers
				maxnumindex =i;
			}
		}
		diffbetween= maxnumindex - minnumindex +1; //subtract the indexes to get the differences
		return diffbetween; //return it
	}

  /*Finding the difference by indexes*/
	public static int minGap(int [] aryIn){
  /*Finding the mingap by comparing the differences to one that already calculated between first 2 numbers*/
		int mindif= aryIn[1]-aryIn[0]; // CONTROL VARABLE, using to compare
		for(int i=2; i<aryIn.length; i++){ 
			if (aryIn[i]-aryIn[i-1]<mindif){ //comparing the init and the new difference, if smaller, update new mindif
				mindif= aryIn[i]-aryIn[i-1];
			}
		}return mindif;
		}
	public static int[] collapse(int[] arrayin){
		int arrayoutsize= (arrayin.length/2)+ (arrayin.length%2); //declaring the size of the array
		//if (arrayin.length%2== 1) arrayoutsize+=1;
		int [] arrayout = new int[arrayoutsize];
		//System.out.print(arrayin.length);
		if (arrayin.length%2 == 0){ //for even arrays
			for (int i=1, outindex=0; i<arrayin.length; i= i+2, outindex++ ){
				int sum = arrayin[i]+arrayin[i-1]; //adding the number i and number b4 it together
				arrayout[outindex]= sum;   //updateing the output array
				//System.out.print(arrayout[outindex]);
			}
		} else if (arrayin.length%2 ==1){ //odd arrays
			arrayout[0]= arrayin[0];
			for (int i=2, outindex=1; i<arrayin.length; i= i+2, outindex++ ){
				int sum = arrayin[i]+arrayin[i-1];  //adding the number i and number b4 it together
				arrayout[outindex]= sum;  //updating the output array
			}
		}	
		return arrayout;
	}
	/*public static void main(String [] args){
		int[] exampleArray = new int[10];
		for(int i = 0; i < 10; i++) {
			exampleArray[i] = i;
			System.out.print("-");
			System.out.print(exampleArray[i]);	
		}
		collapse(exampleArray);
	}*/
	
	
}