/**
 *  Draws ASCII textbooks similar to (but not quite
 *  the same as) Chapter 2, Programming Project 8
 *  in Building Java Programs by Reges & Stepp,
 *  3rd edition.
 *  
 *  @author Thuc Tran
 *  @version G00912103
 * javac -cp .;junitcs211.jar *.java
 * java -cp .;junitcs211.jar _____
 */
class ASCIIBook {
	/**
	 *  Size of the book.
	 */
	private int size;
	
	/**
	 *  Constructor that restricts the size to even
	 *  numbers and ensures the book is not too small
	 *  (not smaller than size 8).
	 *  
	 *  @param size height of the cover of the book
	 */
	public ASCIIBook(int size) {
		this.size = size;
		if(this.size%2 != 0) this.size -= 1;
		if(this.size < 8) this.size = 8;
	}
	
	/**
	 *  Prints the entire ASCII book to the console.
	 */
	public void print() {
		//print top of the book
		printIndent(this.size+1);
		printHorizontalBorder();
		System.out.println();
		
		//print the cover of the book (plus right side)
		for(int i = 1; i <= this.size; i++) {
			printIndent(this.size+1-i);
			printCover(i);
			printRightSide(i+1);
			System.out.println();
		}
		
		printHorizontalBorder();
		printRightSide((this.size/2)+1);
		System.out.println();
		
		//print the bottom side of the book (plus right side)
		for(int i = this.size/2; i > 0; i--) {
			printBottomEdge();
			printRightSide(i);
			System.out.println();
		}
		
		printHorizontalBorder();
		System.out.println();
	}
	
	/**
	 *  Prints some number of spaces to the console.
	 */
	public void printIndent(int numSpaces) {
		/* YOUR CODE HERE */
		String spacesinden= "";
		for (int i =0; i< numSpaces; i++){
			spacesinden= spacesinden + " ";
		}
		System.out.print(spacesinden);
	}
	
	/**
	 *  Prints one line of the cover of the book. Does
	 *  not print the first "/" at the right edge of the book.
	 */
	public void printCover(int rowNumber) {
		/* YOUR CODE HERE */
		/*THE SPACES*/ //27 max in 10, 27-3= 24 spaces max for 10
		//print "/" in the begining
		System.out.print("/");		
		//print the rest of the line
		String theline="___"; //always have the 3 underline things
		for(int i=1; i<=rowNumber; i++){ //go though and add /__ to the end of the string
			if (i >= 2){
			theline= theline + "/__";	
			}			
		}
		int coverSpace = (size*3)- (theline.length());
		//System.out.print((size*3)-theline.length()); //<--- troubleshooting print statement
		printIndent(coverSpace);
		System.out.print(theline);
	}
	
	/**
	 *  Prints some number of dashes which represent
	 *  the right side of the book. If the number of
	 *  dashes is larger than the maximum number of
	 *  dashes needed on any given line, prints the
	 *  maximum instead.
	 *  
	 *  @param numDashes the number of dashes requested
	 */
	public void printRightSide(int numDashes) {
		/* YOUR CODE HERE */
		/*NEED TO FIGURE OUT MAX # OF DASHES*/
		String dasDragoning= "";
		int maxDashes= (size/2)+2; //STILL NEED CHANGES
		if (numDashes< maxDashes){	//checking for max number of dashes
			for (int i =0; i<numDashes;i++){
				dasDragoning= dasDragoning+ "/";
			} 
		}else{ //if it's bigger or equa to the max # dashes
			for (int i =0;i<maxDashes;i++){
				dasDragoning=dasDragoning+"/";
			}
		}
		System.out.print(dasDragoning);
	}
	
	/**
	 *  Prints the part of the book that looks like:
	 *  |    Building Java Programs    |
	 *  The number of spaces between the words and the "|"
	 *  is determined by the size of the book.
	 */
	public void printBottomEdge() {
		/* YOUR CODE HERE */
		//size 10: 30-22= 5 
		int numberofspace= size*3 -22 ; /*NEED TO FIND THE FORMULAR*/; 
		String edge="|"; //tempeary string
		for (int i=0 ; i <= numberofspace; i++){
			if (i == (numberofspace/2)){
				edge = edge +"Building Java Programs";
				//System.out.print("here");
			} else if (i == numberofspace){
				edge = edge + " |";
				//System.out.print("_");
			} else{
				edge = edge + " ";
				//System.out.print("-");
			}
			//System.out.print(i);
		}
		System.out.print(edge);
		
	}
	
	/**
	 *  Prints the part of the book that looks like:
	 *  +------------------------------+
	 *  The number of dashes is determined by the size
	 *  of the book.
	 */
	public void printHorizontalBorder() {
		/* YOUR CODE HERE */ //adjust according to the size with size*3 formular.
		int numberofdash= size*3; 
		String border="+"; //tempeary string
		for (int i=0;i<numberofdash;i++){
			if (i != (numberofdash-1)){
				border= border+ "-";
			}else{
				border= border+"-+";
			}
		}
		System.out.print(border);
	}
}