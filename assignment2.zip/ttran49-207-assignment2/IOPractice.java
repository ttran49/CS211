import java.io.*;
import java.util.*;

/**
 *  Some practice with file I/O.
 */
class IOPractice {
	/**
	 *  An example main method to test functionality.
	 */
	public static String readFromFile(String filename){
		try{	
		//declaring variables
		String out="";
		BufferedReader filein= new BufferedReader (new FileReader(filename));
		boolean nextline=true;
		String a="";
		//while loop to go through the whole file
		while (nextline){
			if ((a = filein.readLine()) != null){ //if there's no next line aka null
				out= out + a;					  // stop the loop
			}else {
				nextline =false;
			}
		}
		
		filein.close();// close the file
		return out;		// return it
		
		}	catch(IOException e){ //exception catching
			return null;
		}
	}
	
	
	public static boolean writeToFile(String fileoutput, String textInput){
		try {
			//create new object with bufferedwriter class
			BufferedWriter fileout = new BufferedWriter (new FileWriter(fileoutput));
			//write to flie and class it
			fileout.write(textInput);
			fileout.close();
			//no expception => return true
			//System.out.print("asdasdas");
			return true;
		} catch (Exception e) {//exception catching
			return false;
		}		
	}
	
	
	public static void main(String[] args) {
		if(args.length != 2) {
			System.out.println("Two command line argument required: (1) input file name (2) output file name");
		}
		else {
			String result1 = IOPractice.readFromFile(args[0]);
			IOPractice.writeToFile(args[1], result1);
			String result2 = IOPractice.readFromFile(args[1]);
			if(result1.equals(result2)) {
				System.out.println("Win!");
			}
			else {
				System.out.println("Not working yet :(");
			}
		}
	}
}