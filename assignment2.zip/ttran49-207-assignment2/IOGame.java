import java.io.*;
import java.util.*;


/**
 *  This class supports a Mad-lib like interactive game.
 */
public class IOGame {
	private int theOrder=0;// use it for the # in promptuser and array size in getuserinput
	String content=""; //the content of the file
	/**
	 *  Constructs a new game from a template contained in a file.
	 *  
	 *  @param fileName the name of the file containing the tempalte
	 *  @throws GameFileNotFoundException if the file in question can not be located
	 */
	public IOGame(String fileName) throws GameFileNotFoundException {
		/** YOUR CODE HERE */
		try{
		readInTemplate(fileName); //check if the file is there, also update the content with the content of the file
		} catch (Exception e){
			throw new GameFileNotFoundException();
		}
	}
	
	
	/**
	 *  Reads in a new template from a file.
	 *  
	 *  @param fileName the name of the file containing the tempalte
	 *  @throws GameFileNotFoundException if the file in question can not be located
	 */
	public void readInTemplate(String fileName) throws GameFileNotFoundException {
		/** YOUR CODE HERE */
		try{
			//COMMENTS GALORE!!!! DECLARING
			content=gettingContent(fileName); //method to read the file and return a string
			boolean ctr= true;
			
			//READER OBJECT
			BufferedReader filein = new BufferedReader(new FileReader(fileName));
			
			//CLOSE
			filein.close();
			
		//THROWING THE GAME.
		} catch(IOException e){
			throw new GameFileNotFoundException();
		}
	
	}
	/**
	*	CREATE A PRIVATE CLASS TO RETURN A SPRING WITH CONTENT OF THE FILE
	*	SO THAT DON'T HAVE TO USE CODE AGAIN. SHORTEN THE CODE
	*
	*/
	
	private String gettingContent(String fileName) throws GameFileNotFoundException{
			try{
			//COMMENTS GALORE!!!! DECLARING
			String localContent="";
			String temp="";
			boolean ctr= true;
			
			//READER OBJECT
			BufferedReader filein = new BufferedReader(new FileReader(fileName));
			
			//GETTING THROUGH FILE
			while(ctr){
				if ((temp = filein.readLine()) != null){ //if there's no next line aka null
					localContent= localContent + temp;			 // stop the loop
				} else {
					ctr =false;
				}
			}
		//CLOSE & RETURN
		filein.close();
		return localContent;
		
		//THROWING THE GAME.
		} catch(Exception e){
			throw new GameFileNotFoundException();
		}
	}
	
	/**get number placemnt holder*/
	public int getNumPlaceHolders(){
		int numPlaceHolders=0;
		String[] ArrayTemp=content.split(" ");
		for (int i = 0; i< ArrayTemp.length;i++){
			if (ArrayTemp[i].startsWith("<")&& ArrayTemp[i].endsWith(">")){
				numPlaceHolders++;
			}
		}
		return numPlaceHolders;
	}
	
	
	
	
	
	/**
	 *  Prompts the user for replacements to the template. This method only
	 *  prints the prompt and does not actually get the user input.
	 */
	public void promptUser() {
		System.out.println("Please enter " + getNumPlaceHolders() + " replacements:");
		/** YOUR CODE HERE */
		//DECLARE
		int startIndex= 0;
		int endIndex=0;
		String temp="";
		
		//GET THE ARRAY
		String [] arrayTemp= content.split(" ");
		
		//GO THROUGH AND FIND THE BLANK SPACES
		for (int i =0; i<arrayTemp.length;i++){
			if (arrayTemp[i].startsWith("<")&& arrayTemp[i].endsWith(">")){
				temp=arrayTemp[i];
				temp= temp.substring(1,temp.length()-1);
				temp= temp.replaceAll("-"," ");
				theOrder++;
				System.out.println(theOrder+". "+temp);
			}
		}
	}
	
	
	/**
	 *  Gets the user input for replacements to the template
	 *  
	 *  @return an array containing each replacement to the template
	 */
	public String[] getUserInput() {
		/** YOUR CODE HERE */
		//CREATE THE ARRAY
		String[] userInput = new String[theOrder];
		
		//CREATE SCANNER OBJECT AND STRING OUTPUT
		Scanner in = new Scanner(System.in);
		String userIn="";
		
		//PROMPTING AND GETTING INPUT FROM USER
		for (int i =0; i < theOrder; i++ ){
			userIn = in.nextLine();
			userInput[i]= userIn;			
		}
		
		//RETURN
		return userInput;
	}
	
	/**
	 *  Gets placeholder replacements from a file
	 *  
	 *  @param fileName the name of the file containing the replacements
	 *  @return an array containing each replacement to the template
	 *  @throws GameFileNotFoundException if the file in question can not be located
	 */
	private int countLine(String fileName){
		int numLine=0;
		try{ 
			BufferedReader filein=new BufferedReader(new InputStreamReader(new FileInputStream(fileName)));
			while(filein.readLine()!= null){
				numLine++;
			}
		filein.close();
		} catch (Exception e){	}
		return numLine;
	}
	public String[] getFileInput(String fileName) throws GameFileNotFoundException {
		/** YOUR CODE HERE */
		try{
			int numLine=countLine(fileName);
			String a="";
			
			//DECLARE ARRAY
			String[] replace= new String[numLine];
			
			//Read in the fileinput file
		BufferedReader filein=new BufferedReader(new InputStreamReader(new FileInputStream(fileName)));
			
			// UPDATING THE ARRAY WITH CONTENT.
			int i=0;
			while ((a=filein.readLine()) != null){
				replace[i]=a;
				i++;
			}
			System.out.print(Arrays.toString(replace));
			//CLOSE FILE || RETURN
			filein.close();	
			return replace;
		} catch(IOException e){
			throw new GameFileNotFoundException();
		}
	}
	
	/**
	 *  Replaces placeholders in the template. If there are not enough
	 *  replacements, then the remaining tokens are displayed without
	 *  being replaced. If there are too many tokens, then the extra
	 *  replacements are ignored.
	 *  
	 *  @param replacements an array of replacements to the template
	 *  @return the template with placeholders replaced
	 */
	public String replace(String[] replacements) {
		
		//VARIABLES
		int reIndex=0;
		String temp="";
		String finalize="";
		
		//GETTING FILE CONTENT
		String[] ConteArray=content.split(" ");
		
		//GOING THROUGH THE array
		int i =0;
		while(i< ConteArray.length){
			//FINDING THE BLANKS
			if (ConteArray[i].startsWith("<")){
				temp=replacements[reIndex];
				ConteArray[i]= replacements[reIndex];		//REPLACE
			
			//CONDITION TO UPDATE THE INDEX OF INPUT ARRAY
			if (reIndex < replacements.length ){
				reIndex++;
			}else if (replacements[reIndex]==replacements[replacements.length-1]) {
					break;
			}		
			}
			i++; //UPDATE THE COUNTER
		}
		//CONVERTING BACK TO A STRING
		for (int j=0; j< ConteArray.length;j++){
			finalize = finalize + ConteArray[j]+" ";
		}
		
		return finalize;
		
	}
	/**
	 *  <p>Replaces placeholders in the template. If there are not enough
	 *  replacements, then the remaining tokens are displayed without
	 *  being replaced. If there are too many tokens, then the extra
	 *  replacements are ignored.</p>
	 *  
	 *  <p>After replacement, writes result to a file.</p>
	 *  
	 *  @param replacements an array of replacements to the template
	 *  @param fileName the name of the file to write to
	 *  @throws OutputFileNotFoundException if the file in question can not be located
	 */
	public void replaceAndWrite(String[] replacements, String fileName) throws OutputFileNotFoundException {
		/** YOUR CODE HERE */
		try{
			//REPLACE THE WORDS
			String finalOutput= replace(replacements);
			
			//CREATING A WRITER OBJECT 
			BufferedWriter crap= new BufferedWriter(new FileWriter(fileName));
			
			//WRITE
			crap.write(finalOutput);
			//CLOSE THE FILE
			crap.close();
			
		} catch (IOException e){
			//THROWS THINGS AROUND
			throw new OutputFileNotFoundException();
		}
	}
	
	/**
	 *  An example main method that runs a small game.
	 *  
	 *  @param args input to the program from the command line
	 */
	public static void main(String[] args) {
		//Below are some code snippets you may find useful when testing your program:
		/*
		IOGame game=null ;
		
		try{
		game = new IOGame("text/example1in.txt");
		game.getFileInput("text/example1rep.txt");
		//game.promptUser();
		//System.out.print("asdkjasdsa");
		//String[] replacements = game.getUserInput();
		//String result = game.replace(replacements);
		//System.out.println("Result: " + result);
		}
		catch (Exception e){}
		/*
		IOGame game =null;
		try{
			game = new IOGame("text/example1in");
			String[] replacements = game.getFileInput("text/example1rep");
			System.out.print(Arrays.toString(replacements));
			game.replaceAndWrite(replacements, "text/test");}
		catch (Exception e) {}
		*/
		//String[] replacements1 = game1.getFileInput("file name goes in here");
		//game1.replaceAndWrite(replacements1, "file name goes in here");
		
		//System.err.println("Error: Could not find requested template file.");
		//System.err.println("Error: Could not find requested template file or answer file.");
		//System.err.println("Error: Could not write to output file.");
		//System.err.println("You must call this program in one of the following ways:\njava IOGame templateFile\njava IOGame templateFile replacementsFile outputFile");
		
	}
}