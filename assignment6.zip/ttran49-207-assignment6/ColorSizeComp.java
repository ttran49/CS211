import java.util.Comparator;
/**
*	Comparator class for Apple class
*	based on its color order and size if the colors are the same
*	Green > Yellow > Red
* 
*	@author Thuc Tran
*	@version G00912103
*/
class ColorSizeComp implements Comparator<Apple>{
	/**
	*	compare the 2 passed in apple object based on its colors and size
	*
	*	@param f1  instance of Apple
	*	@param f2	instance of Apple
	*	@return 	0 if both are same color and size, -1 if f1 color order or size is bigger, -1 if the opposite
	*/
	public int compare(Apple f1, Apple f2) {
		int out=0;
		//System.out.println("COLOR:"+f1.getColor()+"   "+f2.getColor());
		//System.out.println("SIZE:"+f1.getSize()+"   "+f2.getSize());
		if(f1.getColor()==f2.getColor()){
			out= f1.compareTo(f2);
		//f2>f1 color wise
		//GREEN =0; YELLOW=1; RED=2	
		} else if(f1.getColor().ordinal()==0){
			out=1;
		} else if (f1.getColor().ordinal()==1){
			if (f2.getColor().ordinal()==0){
				out= -1;
			} else if(f2.getColor().ordinal()==2){
				out= 1;
			}
		} else if(f1.getColor().ordinal()==2){
			out=-1;
		}
		//System.out.println(out);
		return out;
	}
}