import java.util.Comparator;
class Apple extends Fruit {
	public enum Color {
		GREEN, YELLOW, RED;
		
		public static Color getRandomColor() {
			return values()[(int) (Math.random() * values().length)];
		}
	}
	
	protected Color color;
	/**
	*	Contructor for apple
	*
	*	called super and set the color
	*/
	public Apple() {
		super();
		this.color = Color.getRandomColor();
	}
	
	/**
	*	Getter for color
	*
	*	@return the color of the object
	*/
	
	public Color getColor() {
		return color;
	}
	
	/**
	*	return the size of the Apple with a String format
	*	format = A["*the color of the apple* | *the size of the apple*"]
	*
	*	@return return the size of the apple in String format
	*/
	public String toString() {
		return "A["+(color.toString().charAt(0))+"|"+size+"]";
	}
	
	
	
}