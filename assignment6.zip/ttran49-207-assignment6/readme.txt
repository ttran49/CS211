Thuc Tran
ttran49
G00912103
Lecture: 002
Lab: 207