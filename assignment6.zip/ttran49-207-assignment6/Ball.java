/**
 *  Representing the balls and its numbers 
 *  
 *  @author Thuc Tran
 *	@version G00912103
 */
class Ball
{
	private int number;
	
	/**
	 * @param number the label number of the current ball
	 */
	public Ball(int number)
	{
		//your code here
		this.number=number;
	}
	
	/**
	 * @return the current number of the ball in String format
	 */
	public String toString()
	{
		return "("+this.number+")";
	}
	
	/**
	 * @return the current number of the ball in int format
	 */
	public int getNumber()
	{
		//your code here
		return this.number;
	}
}