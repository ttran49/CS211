import java.util.Random;

/**
 *  Class for the juggler's actions and behavior
 *  
 *  @author Thuc Tran
 */
class Juggler
{
	/**
	 * 
	 */
	private class Hand
	{
		private Ball ball = null;
		
		/**
		 * @param ball an instance of the ball class 
		 */
		public void catchBall(Ball ball)
		{
			try{
			//your code here
			this.ball=ball;
		} catch (Exception e){
			throw new RuntimeException();
		}
		}
		
		/**
		 * @return the ball that is being throw in the air
		 */
		public Ball throwBall()
		{
			try{
			//your code here
			Ball output= this.ball;
			this.ball=null;
			return output;
		} catch (Exception e){
			throw new RuntimeException();
		}
		}
		
		/**
		 * @return a boolean represent if there is a ball in the juggler's hand
		 */
		public boolean hasBall(){
			//your code here
		if (this.ball == null){
			return false;
		} else{
			return true;
		}
		}
		
		/**
		 * @return the current ball number
		 */
		public String toString()
		{
			if(this.ball == null)
				return "   ";
			return this.ball.toString();
		}
	}
	
	/*-------------- DO NOT CHANGE ANYTHING BELOW THIS LINE --------------*/
	
	private Air<Ball> air = new Air<>();
	private Hand[] hands = new Hand[2];
	private int numUnthrownBalls;
	private int totalBalls;
	
	/**
	 * 
	 */
	public Juggler()
	{
		hands[0] = new Hand();
		hands[1] = new Hand();
		this.totalBalls = this.numUnthrownBalls = ((new Random()).nextInt(5))+3;
	}
	
	/**
	 * 
	 */
	public void passBall()
	{
		hands[0].catchBall(hands[1].throwBall());
	}
	
	/**
	 * 
	 */
	public void throwBall()
	{
		if(!hands[0].hasBall() && this.numUnthrownBalls > 0)
			air.add(new Ball(this.numUnthrownBalls--));
		else
			air.add(hands[0].throwBall());
	}
	
	/**
	 * 
	 */
	public void catchBall()
	{
		hands[1].catchBall(air.remove());
	}
	
	/**
	 * @return 
	 */
	public int getNumUnthrownBalls()
	{
		return this.numUnthrownBalls;
	}
	
	/**
	 * @return 
	 */
	public String toString()
	{
		String spacing = "";
		if(this.totalBalls < 7) spacing += "   ";
		if(this.totalBalls < 5) spacing += "   ";
		
		return spacing + air.toString() + "\n\n      "
			+ hands[0].toString() + "( )" + hands[1].toString() + "\n   "
			+ "    \\__|__/\n   "
			+ ((this.numUnthrownBalls > 6) ? "(7)" : "   ")
			+ ((this.numUnthrownBalls > 5) ? "(6)" : "   ")
			+ " |\n   "
			+ ((this.numUnthrownBalls > 4) ? "(5)" : "   ")
			+ ((this.numUnthrownBalls > 3) ? "(4)" : "   ")
			+ " |\n   "
			+ ((this.numUnthrownBalls > 2) ? "(3)" : "   ")
			+ ((this.numUnthrownBalls > 1) ? "(2)" : "   ")
			+ "/ \\\n   " 
			+ ((this.numUnthrownBalls > 0) ? "(1)" : "   ")
			+ "  /   \\\n";
	}
}