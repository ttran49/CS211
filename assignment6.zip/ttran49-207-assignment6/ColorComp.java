import java.util.Comparator;
/**
*	Comparator class for Apple class
*	based on its color order
*	Green > Yellow > Red
* 
*	@author Thuc Tran
*	@version G00912103
*/
class ColorComp implements Comparator<Apple>{
	/**
	*	compare the 2 passed in apple object based on its colors
	*
	*	@param f1  instance of Apple
	*	@param f2	instance of Apple
	*	@return 	0 if both are same color, -1 if f1 color order is bigger, -1 if the opposite
	*/
	public int compare(Apple f1, Apple f2) {
		int out=0;
		if(f1.getColor()==f2.getColor()){
			out= 0;
		} else if (f1.getColor().ordinal() > f2.getColor().ordinal()){
			out=-1;
		} else{
			out=1;
		}
	return out;
	}
}