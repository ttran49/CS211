import java.util.Collection;
import java.util.Queue;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 *  YOUR COMMENTS HERE
 * 
 *  For the Queue interface, see http://docs.oracle.com/javase/8/docs/api/java/util/Queue.html
 *  and http://docs.oracle.com/javase/tutorial/collections/interfaces/queue.html
 *  
 *  @author Thuc Tran
 *	@version G00912103
 */
class Air<T> implements Queue<T>
{
	/**
	 * Wikipedia claims max solo record is 13
	 * see http://en.wikipedia.org/wiki/Juggling_world_records#Solo_records
	 * Allowing room for growth...
	 */
	public static final int MAX_CAPACITY = 15;

	/**
	 * 
	 */
	private class ListItem<T>
	{
		//your code here
		private T thing;
		private ListItem data;
		//Contructor
		public ListItem(T thing, ListItem data ){
			this.thing=thing;
			this.data=data;
		}
		//SETTERS
		public void setThing(T thing){
			this.thing=thing;
		}
		public void setData(ListItem data){
			this.data=data;
		}
		//GETTERS
		public T getThing(){
			return this.thing;
		}
		public ListItem getData(){
			return this.data;
		}
	}
	
	private ListItem<T> head;
	
	//you code here... maybe you want some other variables?
	
	private ListItem<T> tail;
	private int size=0;

	/**
	 * Adding elements to the list
	 * @param item the element to be added to the list
	 * @return ture if the element is successfully added
	 */
	public boolean add(T item)
	{
		//your code here - remember to throw all appropriate exceptions		
		//add always returns true, see: http://docs.oracle.com/javase/8/docs/api/java/util/Collection.html#add-E-
		try{
			ListItem temp=new ListItem(item, null);
			size++;
			if (head!=null){
				tail=temp;
				tail.setData(temp);
			} else{
				head=temp;
				tail=temp;
			}
			return true;
		} catch (Exception e){
			return false;
		}
	}
	
	/**
	 *  Check and add the object the to list if there is space
	 *
	 * @param item T object to pass in for add if there is space
	 * @return true if there are space and successfully added to the list
	 */
	public boolean offer(T item)
	{
		try{
		if (size <= MAX_CAPACITY){
			add(item);
			return true;
		}
		return false;
	} catch (Exception e){
		return false;
	}
	}

	/**
	 * 
	 * @return
	 */
	public T remove()
	{
		//your code here - remember to throw all appropriate exceptions
		ListItem<T>temp=head;
		head=head.getData();
		size--;
		return temp.getThing();
	}
	
	/**
	 * 
	 * @return
	 */
	public T poll()
	{
		//your code here
		T temp= peek();
		if (temp!= null){
			remove();
			return temp;
		}
		return null;
	}
	
	/**
	 * 
	 * @return
	 */
	public T element()
	{
		//your code here - remember to throw all appropriate exceptions
		T temp= peek();
		if(temp== null)
			throw new NoSuchElementException();
		return temp;
	}
	
	/**
	 * 
	 * @return the first element of the list
	 */
	public T peek()
	{
		//your code here
		if (size ==0)
			return null;
		return head.getThing();
	}

	/**
	 * 
	 * @return a string that present the current ball
	 */
	public String toString()
	{
		//your code here
		if(tail!= null){
			return "("+this.tail.getThing()+")";
		} else if(tail== null && head!= null){
			return "("+this.head.getThing()+")";
		} else{
			return "   ";
		}
	}
	
	/**
	 *	Clear the list. 
	 *
	 */
	public void clear()
	{
		//your code here
		head=null;
		tail=null;
	}
	
	/**
	 *	Check if the list is empty 
	 *
	 * @return true if the list is empty
	 */
	public boolean isEmpty()
	{
		//your code here
		if(size!=0)
			return true;
		return false;
	}
	
	/**
	 *
	 */
	public int size()
	{
		//your code here
		return size;
	}
	
	/**
	 *
	 */
	public Object[] toArray()
	{
		//your code here
		Object[] output= new Object[size];
		output[0]= head.getThing();
		ListItem<T>next = head;
		for(int i =0;(next=head.getData())!=null;i++){
			output[i]= next;
		}
		return output;
	}
	
	/*-------------- DO NOT CHANGE ANYTHING BELOW THIS LINE --------------*/
	
	/**
	 * DO NOT CHANGE THIS
	 */
	public boolean addAll(Collection<? extends T> c)  
	{
		throw new UnsupportedOperationException();
	}
	
	/**
	 * DO NOT CHANGE THIS
	 */
	public boolean contains(Object o)
	{
		throw new UnsupportedOperationException();
	}
	
	/**
	 * DO NOT CHANGE THIS
	 */
	public boolean containsAll(Collection<?> c)
	{
		throw new UnsupportedOperationException();
	}
	
	/**
	 * DO NOT CHANGE THIS
	 */
	public boolean equals(Object o)
	{
		throw new UnsupportedOperationException();
	}
	
	/**
	 * DO NOT CHANGE THIS
	 */
	public int hashCode()
	{
		throw new UnsupportedOperationException();
	}
	
	/**
	 * DO NOT CHANGE THIS
	 */
	public Iterator<T> iterator()
	{
		throw new UnsupportedOperationException();
	}
	
	/**
	 * DO NOT CHANGE THIS
	 */
	public boolean remove(Object o)
	{
		throw new UnsupportedOperationException();
	}
	
	/**
	 * DO NOT CHANGE THIS
	 */
	public boolean removeAll(Collection<?> c)
	{
		throw new UnsupportedOperationException();
	}
	
	/**
	 * DO NOT CHANGE THIS
	 */
	public boolean retainAll(Collection<?> c)
	{
		throw new UnsupportedOperationException();
	}
	
	/**
	 * DO NOT CHANGE THIS
	 */
	public <E> E[] toArray(E[] a)
	{
		throw new UnsupportedOperationException();
	}
}