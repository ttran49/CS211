/**
 *  Performs various recursive operations.
 *  
 *  @author Thuc Tran
 *  @version G00912103
 */
 class Assignment7 {
	/**
	 *  Determine whether an array of characters is a palindrome.
	 *  
	 *  Hint: you may want a helper method for this.
	 *  
	 *  @param input the array to check
	 *  @return whether or not the array is a palindrome
	 */
	public static boolean arrayPalindrome(char[] input) {
		Assignment7SampleTests.hasRecursion(); //make sure this is at the start of every recursive method...
		if(input.length==0 || input.length==1)
			return true;
		if(input[0]==input[input.length-1])
			return arrayPalindrome(reduceArray(input));
		return false;
	}
	/***
	 *  reduce the char[] by size of 2 bying taking away
	 *  the first and last element
	 *  @param input the input char[] to be reduced
	 *  @return the input array with head and last element took off, size-2
	 */
	private static char[] reduceArray(char [] input){
		char[] output= new char[input.length-2];
		for(int i=1, j=0; i< input.length-1 ;i++ , j++){
			output[j]=input[i];
		}
		return output;
	}
	
	/**
	 *  Count the number of nulls in an array of objects.
	 *  
	 *  Hint: you may want a helper method for this.
	 *  
	 *  @param inputArray the array to look for nulls in
	 *  @return the number of elements of the array which are null
	 */

	public static int nullsInArray(Object[] inputArray) {
		Assignment7SampleTests.hasRecursion(); //make sure this is at the start of every recursive method...
		int i=0;
		if(inputArray.length==0){
			return i;
		}
		if(inputArray[0]==null){
			i=1+ nullsInArray(reduceObjectArray(inputArray));
		}else {
			i=0+nullsInArray(reduceObjectArray(inputArray));
		}
		return i;
	}
	
	/***
	 *  reduce the object array by 1 elements by take out the first
	 *  element of the array
	 *  @param input the object array to be used to reduce
	 *  @return an obejct array with size -1 from the input and start from the second element
	 */
	 
	private static Object[] reduceObjectArray(Object [] input){
		Object[] output= new Object[input.length-1];
		for(int i=1, j=0; i< input.length ;i++ , j++){
			output[j]=input[i];
		}
		return output;
	}
	
	/**
	 *  Count number of 0s in linked list of ints (starting at
	 *  a given node);
	 *  
	 *  Hint: you don't need a "helper" method for this.
	 *  
	 *  @param head the head of the linked list
	 *  @return the number of 0s in the linked list
	 */
	public static int zerosInLinkedList(Node head) {
		Assignment7SampleTests.hasRecursion(); //make sure this is at the start of every recursive method...
		int counter=0;
		if(head!= null){
			if(head.value==0){
				counter= 1 + zerosInLinkedList(head.next);
			} else
				counter=0+zerosInLinkedList(head.next);
		}
		return counter; //replace this
	}
	
	/**
	 *  Multiply all the values in a linked list of ints (starting
	 *  at a given node);
	 *  
	 *  Hint: you don't need a "helper" method for this.
	 *  Note: DO NOT USE the exception thrown to control your recursion!
	 *  
	 *  @throw NullPointerException if head is null
	 *  @param head the head of the linked list
	 *  @return product of all the values in the linked list
	 */
	 //need to figure out how to carry over i
	public static int multiplyNodes(Node head) {
		Assignment7SampleTests.hasRecursion(); //make sure this is at the start of every recursive method...
		int i=1 *head.value;
		if((head.next)!= null){
			i=i*multiplyNodes(head.next);
			return i;
		}else
			return head.value;
	}
	
	/**
	 *  Merge sort
	 *  
	 *  Note: Pseudocode given in class. DO NOT TAKE CODE FROM THE INTERNET!
	 *  Note: DO NOT USE the exception thrown to control your recursion!
	 *  Note: You'll probably want a helper method for this
	 *  
	 *  @throw NullPointerException if list is null
	 *  @param head the head of the linked list
	 */
	public static void mergeSort(int[] array) {
		Assignment7SampleTests.hasRecursion(); //make sure this is at the start of every recursive method...
		if(array.length<=1)
			return;
		//make arrays
		int half= array.length/2;
		int[] firsthalf= new int[half];
		int[] secondhalf= new int[array.length-half];
		
		//update the arrays
		System.arraycopy(array,0,firsthalf,0,half);
		System.arraycopy(array,half,secondhalf,0,array.length-half);
		
		//recursive call
		mergeSort(firsthalf);
		mergeSort(secondhalf);
		
		//MERGE
		int stepFirst=0;
		int stepSecond=0;
		for(int i=0; i<array.length;i++){
			if (firsthalf[stepFirst]<=secondhalf[stepSecond]){
				array[i]= firsthalf[stepFirst];
				stepFirst++;
			} else if(secondhalf[stepSecond]<=firsthalf[stepFirst]){
				array[i]= secondhalf[stepSecond];
				stepSecond++;
			} else if(stepFirst==firsthalf.length-1){
				array[i]= secondhalf[stepSecond];
				stepSecond++;
			} else if(stepSecond==secondhalf.length-1){
				array[i]= firsthalf[stepFirst];
				stepFirst++;
			}
		}
	}	
	/**
	 *  DO NOT CHANGE THIS CLASS
	 *  
	 *  This class forms a very simple linked list with just nodes
	 */
	static class Node {
		int value;
		Node next;
		
		public Node(int value) {
			this.value = value;
		}
		
		public void setNext(Node next) {
			this.next = next;
		}
	}
}