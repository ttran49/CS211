import org.junit.*;
import static org.junit.Assert.*;

public class JUnitPracticeTests {
	/* PUT YOUR TEST METHODS HERE */
	@Test
	public void divides01(){
		//setup
		JUnitPractice test= new JUnitPractice();
		double num= test.divides(0,123);
		//assert
		assertEquals(0.0, num,0.0);
	}
	/**
	* 	TEST FOR ARITHMETIC EXCEPTION
	*/
	@Test (expected = ArithmeticException.class)  
	public void divides02() {
		//setup
		JUnitPractice test= new JUnitPractice();
		//test
		test.divides(2262,0);
		//assert
		assertEquals(0.0, test.divides(2262,0),0.0);
	}
	@Test
	public void divides03(){
		//setup
		JUnitPractice test= new JUnitPractice();
		//test
		assertEquals( -111.6666666667,test.divides(-2345,21),0.000001);
	}
	
	@Test
	public void count01(){
		//setup
		int[] test= new int[6];
		for(int i =0;i<5;i++){
			test[i]=i;
		}
		test[5]=0;
		
		//testing
		JUnitPractice test1= new JUnitPractice();
		int num =test1.count(test,0);
		//assert
		assertEquals(2,num);
	}
	/**
	* TEST FOR NULL POINTER EXCEPTION
	*/
	@Test (expected= NullPointerException.class)
	public void count02(){
		//setup
		int[] test1= null;
		JUnitPractice test = new JUnitPractice();
		
		//test
		assertEquals(2,test.count(test1,3));
	}
	//run the test file
	public static void main(String args[]) {
		org.junit.runner.JUnitCore.main("JUnitPracticeTests");
	}
}