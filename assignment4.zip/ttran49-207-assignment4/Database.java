import java.io.*;
import java.util.Scanner;
class Database extends databaseSupport implements Library{
	private static String libraryFileName="";
	private static String filePath="";
	
	/**
	 *  Sets the library to use a specific database file.
	 *  
	 *  @param libraryFileName the name of the file which contains the list of book files
	 *  @return true if the database file was set, false if an error occurred
	 */
	public boolean setLibraryFile(String libraryFileName){ //MIGHT BE WRONG UZ WRONG IDEA
		try{
			boolean ctr = true;
			String temp="";
			
			//READER OBJECT
			BufferedReader filein = new BufferedReader(new FileReader(libraryFileName));
			
			//READ IN THE CONTENT OF THE libraryFileName
			while(ctr){
				if ((temp = filein.readLine()) != null){ 
					filePath= filePath + temp;			 
				} else {
					ctr =false;
				}
			}
			
			//CLOSE
			filein.close();
			this.libraryFileName=libraryFileName;
			return true;
			
		//WHEN NOT FIND OR PROBABLY SET THE FILE
		} catch(IOException e){
			return false;
		} 
	}
	
	/**
	 *  Returns the current library file
	 *  
	 *  @return the current library file, null if no file set
	 */
	public File getLibraryFile() {
		File file=null;
		if(setLibraryFile(libraryFileName)) {
			file= new File(libraryFileName);
		} 
		return file;
	}
	
	
	/**
	 *  Gets the number of books in the library.
	 *	GETTING THE WHOLE PATH
	 * ******************************
	 *	1/ get path from file in
	 *	2/ update list elements
	 *	GETTING JUST THE FILE NAMES
	 *	*****************************
	 *	1/ getting filepath from reading filein
	 *	2/ Get name by getName()
	 *	3/ update list elements
	 *  
	 *  @param withPath specifies if the return strings should include the path to the files or just the file names
	 *  @return an array of book files contained in the library, null if no library
	 */
	public String[] getLibraryBooks(boolean withPath){
		//GET SIZE AND DECLARE STUFFS
		int x = databaseSize();
		String[] bookfile= new String[x];
		
		String temp="";
		boolean ctr=true;
		int index=0;		
		
		//DOING WHAT THE DESCRIPTION SAID
		try{
			BufferedReader filein = new BufferedReader(new FileReader(libraryFileName));
			while(ctr){
				if ((temp = filein.readLine()) != null){  
					if (withPath){
						bookfile[index]= temp;
						index++;
					} else{
						File fileinstance= new File(temp);
						bookfile[index]= fileinstance.getName();
						index++;
					}
				} else {
					ctr = false;
				}
			}
		} catch (IOException e){ return null;}
	return bookfile;
	}
	
	/**
	 *  Gets the number of books in the previously set library.
	 *  
	 *  @return the number of books in the library, -1 if no library has been set
	 */
	public int getNumberOfBooks() {
		boolean isSet =setLibraryFile(libraryFileName);
		int x=-1;
		if (isSet){
			if (databaseSize()!=0){
				x=databaseSize();
			}else {
				x=0;
			}			
		} 
		return x;
	}
	
	/**
	 *  Gets the number of times a phrase appears in the library.
	 *  In other words, checks every book in the library and adds up the
	 *  number of times the phrase has appeared in all books. Note: if
	 *  the phrase appears across multiple lines (e.g. the book contains
	 *  "the\nhouse" and you search for "the house", "the\nhouse" should
	 *  be counted).
	 *  
	 *  @param phrase the phrase to look for
	 *  @return the number of times the phrase appears in the entire library, -1 if no library has been set
	 */
	public int getLibraryOccurrences(String phrase){
		/*get all the content to 1 string, replace \n,\r\f maybe then find
		the word/phrase
		loop through to get the filepath- pass it to getFileCont, update the sttring
		replace
		for loop & find
		*/
		int timeRep=-1;
		boolean ctr=true;
		String Content="";
		String temp="";
		
		//GO THROUGH THE DATABASE FILE, GET PATH, AND UPDATE THE CONTENT
		try {
			BufferedReader filein = new BufferedReader(new FileReader(libraryFileName));
			while (ctr){
			if((temp=filein.readLine())!= null){
				Content= Content+ getFileCont(temp); 
			}else{
				ctr=false;
				}
			}
		} catch (IOException e) { }
		
		//REMOVING \N,\R,\F
		Content= Content.replaceAll("\n","");
		Content=Content.replaceAll("\r","");
		Content= Content.replaceAll("\f","");
		
		//finding
		for(int i= phrase.length(); i< Content.length();i=i+phrase.length()){
			if (Content.substring(i-phrase.length(),i).equals(phrase)){
				timeRep++;
			}
		}
		//ADD 1 if the file is set; default =0
		if (setLibraryFile(libraryFileName)){
			timeRep++;
		}
	return timeRep;
	}
	
	/**
	 *  Gets the percentage of books in the library that use a certain
	 *  set of characters to denote a newline. For example, if 50% of
	 *  the books use "\r\n" to denote a new line, and newlineChars
	 *  is set to {'\r', '\n'}, this method will return 0.5
	 *  
	 *  @param newlineChars an array containing the sequence of character which might denote a new line
	 *  @return the percent of books in the library which use the given sequence for new lines
	 */
	public double getLibraryNewlinePercentage(char[] newlineChars){
		double conBooks=0.0;
		double numBook= databaseSize();
		String ctr="";
		boolean loopCtr=true;
		String temp="";
		String Content="";

		try {
		String[] fileNames=getLibraryBooks(true);
		for(int i=0; i< fileNames.length;i++){
			FileReader file= new FileReader(fileNames[i]);
			int character;
			while((character=file.read())!= -1){
				if((char) character == newlineChars[0]){
					//13 is \r, 10 is \n
					if(newlineChars.length != 1){
						character=file.read();
						if ((char) character==newlineChars[1])
							conBooks++;
							break;
					}
					conBooks++;
					break;
				}
			}
			file.close();
		}
		} catch (IOException e) { }
		
		return conBooks / numBook;
		
	}
	
	/**
	 *  Gets the number of times a phrase appears in a given book.
	 *  Note: if the phrase appears across multiple lines (e.g. the
	 *  book contains "the\nhouse" and you search for "the house",
	 *  "the\nhouse" should be counted).
	 *  
	 *  Accepts a book number which assumed to be an index into the
	 *  array returned by #getLibraryBooks(boolean).
	 *  
	 *  @param bookNumber an index into the set of books in the library
	 *  @param phrase the phrase to look for
	 *  @return the number of times the phrase appears in the book, -1 if the bookNumber is out of bounds of the library
	 */
	public int getBookOccurrences(int bookNumber, String phrase){
		int counter=-1;
		
		String fileContent="";
		String tempFile= "";
		try {tempFile=getLibraryBooks(true)[bookNumber];
			 fileContent=getFileCont(tempFile);	
			 } 
		catch (IndexOutOfBoundsException e){ return counter; }
		catch (IOException e){ }
		
		//REMOVING
		fileContent= fileContent.replaceAll("\n","");
		fileContent= fileContent.replaceAll("\f","");
		fileContent= fileContent.replaceAll("\r","");
		fileContent= fileContent.replaceAll("[!.;?,:\"'/\\()`]", " ");
		
		//GOING THROUG AND FIND PHRASE
		for (int i =phrase.length(); i <= fileContent.length(); i=i+phrase.length()){
			if (fileContent.substring(i-phrase.length(), i).equals(phrase)){
				counter++;
			}
		}
		return counter ++;
	}
	
	/**
	 *  Gets the number of lines in a given book.
	 *  
	 *  Accepts a book number which assumed to be an index into the
	 *  array returned by #getLibraryBooks(boolean).
	 *  
	 *  @param bookNumber an index into the set of books in the library
	 *  @return the number of lines in the given book, -1 if the bookNumber is out of bounds of the library
	 */
	public int getBookNumLines(int bookNumber){
		int counter=-1;
		String tempFile= "";
		boolean isIn= true;
		String fileCon="";
		
		//CHECK FOR OUTOFBOUND
		try{ tempFile= getLibraryBooks(true)[bookNumber];
			 Scanner AA= new Scanner(new FileReader(tempFile));
			 while(AA.hasNext()){
				 counter++;
				 AA.nextLine();
			 }
			AA.close();
			}
		catch(IndexOutOfBoundsException e){ isIn=false;} 
		catch(IOException e) { }
		
		// RUN IF NOT OUTOFBOUND
		if (isIn){
			counter++;
		}
		return counter;
	}
	
	/**
	 *  Returns the set of characters which denote a newline in
	 *  a given book. For example {'\r', '\n'} or {'\n'}. If the
	 *  book uses more than one newline character set, use the first
	 *  one found.
	 *  
	 *  Accepts a book number which assumed to be an index into the
	 *  array returned by #getLibraryBooks(boolean).
	 *  
	 *  @param bookNumber an index into the set of books in the library
	 *  @return the sequence of characters used to denote the newline in this book, null if the bookNumber is out of bounds of the library
	 */
	public char[] getBookNewlineCharacters(int bookNumber){
		int x=0;
		String fileContent="";
		
		try{ String tempFile= getLibraryBooks(true)[bookNumber];
			fileContent=getFileCont(tempFile); }
		catch(IndexOutOfBoundsException e){ return null;}
		catch(IOException e){ }

		//FINDING SIZE OF ARRAY
		if (fileContent.contains("\n") && fileContent.contains("\r") ) 		{x=2;}
		else if (fileContent.contains("\r") | fileContent.contains("\n")) 	{x=1;}
		char[] fin= new char[x];
		
		boolean foundN =false; 
		boolean foundR= false;
		
		int count = 0;
		for (int i =1; i< fileContent.length()+1;i++){
			//FIRST MEMBER
			if(fileContent.substring(i-1,i).equals("\r")&& !foundR){
				fin[count]='\r'; // change this to \r
				count++;
				foundR=true;
			}
			else if(fileContent.substring(i-1,i).equals("\n") && !foundN){
				fin[count]='\n'; // change this to \n
				count++;
				foundN=true;
			}	
		}
		return fin;

	}
	/**
	*	return the number of book/ size of the database by counting numbers of path in database.txt
	*
	*	@return numLine number of pathfile in the database file
	*/
	private int databaseSize(){
		int numLine=0;
		try{ 
			BufferedReader filein=new BufferedReader(new InputStreamReader(new FileInputStream(libraryFileName)));
			while(filein.readLine()!= null){
				numLine++;
			}
		filein.close();
		} catch (Exception e){	}
		return numLine;
	}
	
	/**	get the file content and put it in a string
	*
	*	@param pathFile path of the file
	*	@return content the content of the book or file that provided by the path
	*	@throws IOException 
	*/
	private	String getFileCont (String pathFile) throws IOException {
		String content="";
		String temp="";
		String separator= System.getProperty("line.separator");
		boolean ctr=true;
		
		try{
			BufferedReader filein = new BufferedReader(new FileReader(pathFile));
			//read the file and add it to string
			while(ctr){
			if((temp=filein.readLine())!= null){
				content= content+ temp + separator;
			}else{
				ctr=false;
				}
			}
		} catch(IOException e){ }
		return content;
	}
		

	public static void main (String[] agrs){
		Database test= new Database();
		test.setLibraryFile("text/database.txt");
		//System.out.println(test.getLibraryFile());
		//String[] a=test.getLibraryBooks(false);
		//System.out.println(Arrays.toString(a));
		//System.out.println(test.getNumberOfBooks());
		//System.out.println(test.getLibraryOccurrences("lalalalalalal alalalla lalala"));
		//System.out.println(test.getBookOccurrences(0,"the house"));
		//System.out.println(test.getBookNumLines(1));
		//test.getBookNewlineCharacters(2); //notworkkin
		//char[] testchar= {'\r','\n'};
		//test.getLibraryNewlinePercentage(testchar);
	}	
}